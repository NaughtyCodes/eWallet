# Spring 4 RESTFul Controller Example (REST CRUD Example)
Template example for Spring 4 MVC + RESTful Service with pure Java Configuration (no XML), using Maven build tool.

###1. Technologies
* Spring 4.3.1.RELEASE
* Maven 3.3.3

###2. To Run this project locally
```shell
$ git clone https://github.com/viralpatel/spring4-restful-example
$ mvn tomcat7:run
```
Access ```http://localhost:8080/springrest/customers```

![Spring 4 REST Tutorial](http://img.viralpatel.net/2016/06/spring-4-mvc-rest-controller-service-restful.png) 

###3. To import this project in Eclipse IDE
1. ```$ mvn eclipse:eclipse```
2. Import into Eclipse via **existing projects into workspace** option.
3. Done. 


###4. Project Demo
Please refer to this article [Spring 4 RESTFul Service Tutorial](http://viralpatel.net/blogs/spring-4-mvc-rest-example-json/)

# https://docs.spring.io/spring/docs/current/spring-framework-reference/html/mvc.html#mvc-config
# Maveen complete tutorial 
# http://www.mkyong.com/tutorials/maven-tutorials/
#MAVEEN Commends
>mvn eclipse:eclipse
>mvn package 

#install dependency
mvn dependency:resolve
#How to build project with Maven
�mvn package� to build project.
#How to clean project with Maven
�mvn clean� to clean project.
#How to run unit test with Maven
�mvn test� to run unit test.
#How to install your project into Maven local repository
�mvn install� to package and deploy project to local repository.
#How to generate a documentation site for your Maven based project
�mvn site� to generate documentation site for your project information.
#How to deploy site with �mvn site-deploy� � WebDAV example
�mvn site-deploy� to deploy generated documentation site to server automatically, via WebDAV.
#How to deploy Maven based war file to Tomcat
�mvn tomcat:deploy� to deploy WAR file to Tomcat.

Tables
  customer
  customer_group
  account
  transaction_reference
  
Table Structure

  customer:
    -id
    -group_id
    -name
    -details
    
  customer_group:
    -id
    -group_name
    -interest
    
   account:
    -id
    -customer_id
    -currency
    -amount
    -interest
    -outstanding
    -updated_on
    
   transaction_reference:
    -id
    -credit_account_id
    -debit_account_id
    -amount
    -txn_note
    -timestamp