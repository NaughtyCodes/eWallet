package org.ewallet.service;

import java.util.List;

import org.ewallet.model.User;
import org.springframework.stereotype.Service;


public interface UserService {
	
	public User addUser(User user);
	public User updateUser(User user);
	public User removeUser(User user);
	public List<User> list();
	public User getUser(Long id);
	
}
