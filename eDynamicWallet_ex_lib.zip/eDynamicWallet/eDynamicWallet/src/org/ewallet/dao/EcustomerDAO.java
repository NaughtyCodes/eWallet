package org.ewallet.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.RowMapper;

import org.ewallet.model.Ecustomer;

@Component
public class EcustomerDAO {
	
	private JdbcTemplate jdbcTemplate;
	
	public EcustomerDAO(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<Ecustomer> list(){
		String sql = "SELECT * FROM customer";
		List<Ecustomer> listCustomer = jdbcTemplate.query(sql, new RowMapper<Ecustomer>(){

			@Override
			public Ecustomer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Ecustomer customer = new Ecustomer();
				customer.setId(rs.getInt("id"));
				customer.setGroupId(rs.getInt("group_id"));
				customer.setName(rs.getString("name"));
				customer.setDetails(rs.getString("details"));
				
				return customer;
			}
			
		});
		
		return listCustomer;
	}

}
