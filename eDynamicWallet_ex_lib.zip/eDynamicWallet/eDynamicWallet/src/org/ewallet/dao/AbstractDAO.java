package org.ewallet.dao;

import java.util.List;

public interface AbstractDAO<T> {
	
    public void saveOrUpdate(T t);
    
    public void delete(int id);
     
    public T get(int id);
     
    public List<T> list();

}
