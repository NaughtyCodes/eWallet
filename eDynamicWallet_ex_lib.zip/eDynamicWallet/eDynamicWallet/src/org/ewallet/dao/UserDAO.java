package org.ewallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.ewallet.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Component
public class UserDAO implements AbstractDAO {
	
	private JdbcTemplate jdbcTemplate;
	private DataSource dataSource;
	
	public UserDAO(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
		this.dataSource = dataSource;
	}
	
	
	@Override
	public void saveOrUpdate(Object user) {
		// TODO Auto-generated method stub
		try {
			Connection conn = dataSource.getConnection();
			String sql = "INSERT INTO user (group_id, first_name, last_name, email, mobile, dob, password, details) VALUES (?,?,?,?,?,?,?,?)";
			System.out.println(sql);
			PreparedStatement stmt=conn.prepareStatement(sql);
			
			User param = (User)user;
			
			//stmt.setLong(1,param.getId());
			stmt.setLong(1,param.getGroupId());
			stmt.setString(2,param.getFirstName());
			stmt.setString(3,param.getLastName());
			stmt.setString(4,param.getEmail());
			stmt.setLong(5,param.getMobile()); 
			stmt.setDate(6,param.getDateOfBirth()); 
			stmt.setString(7,param.getPassword());
			stmt.setString(8,param.getDetails());     
			  
			int i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
			  
			conn.close();
			
			System.out.println(i);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object get(int id) {
		// TODO Auto-generated method stub
		String sql = "select * from user where id = "+id;
		System.out.println(sql);
		List<User> listUser = jdbcTemplate.query(sql, new RowMapper<User>(){

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User user = new User();
				user.setId(rs.getLong("id"));
				user.setGroupId(rs.getLong("group_id"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				user.setLastName(rs.getString("last_name"));
				user.setEmail(rs.getString("email"));
				user.setMobile(rs.getLong("mobile"));
				user.setDateOfBirth(rs.getDate("dob"));
				user.setPassword(rs.getString("password"));
				user.setDetails(rs.getString("details"));
				
				return user;
			}
		});
		
		return listUser.get(0);
	}

	@Override
	public List list() {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM user";
		List<User> listUser = jdbcTemplate.query(sql, new RowMapper<User>(){

			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User user = new User();
				user.setId(rs.getLong("id"));
				user.setGroupId(rs.getLong("group_id"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				user.setLastName(rs.getString("last_name"));
				user.setEmail(rs.getString("email"));
				user.setMobile(rs.getLong("mobile"));
				user.setDateOfBirth(rs.getDate("dob"));
				user.setPassword(rs.getString("password"));
				user.setDetails(rs.getString("details"));
				
				return user;
			}
			
		});
		
		return listUser;
	}
	
	

}
