package org.ewallet.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;
import org.ewallet.model.CustomerGroup;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class CustomerGroupDAO implements AbstractDAO {
	
    private JdbcTemplate jdbcTemplate;
    
    public CustomerGroupDAO(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
	
    @Override
    public List<CustomerGroup> list() {
        String sql = "SELECT * FROM customer_group";
        List<CustomerGroup> listCustomerGroup = jdbcTemplate.query(sql, new RowMapper<CustomerGroup>() {
     
            @Override
            public CustomerGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
            	CustomerGroup customerGroup = new CustomerGroup();
     
            	customerGroup.setId(rs.getInt("id"));
            	customerGroup.setGroupName(rs.getString("group_name"));
            	customerGroup.setInterestRate(rs.getInt("interest_rate"));
                   
                return customerGroup;
            }
     
        });
     
        return listCustomerGroup;
    }

	@Override
	public void saveOrUpdate(Object t) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object get(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
