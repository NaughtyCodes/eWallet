package org.ewallet.model;

public class Ecustomer {

	private Integer id;
	private Integer groupId;
	private String name;
	private String details;
	
	
	/**
	 * @param id
	 * @param groupId
	 * @param name
	 * @param details
	 */
	public Ecustomer(Integer id, Integer groupId, String name, String details) {
		this.id = id;
		this.groupId = groupId;
		this.name = name;
		this.details = details;
	}
	
	public Ecustomer(){}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
	

}
