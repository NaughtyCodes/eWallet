package org.ewallet.model;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class CustomerGroup {

	private Integer id;
	private String groupName;
	private Integer interestRate;
	

    
	/**
	 * @param id
	 * @param groupName
	 */
	public CustomerGroup(Integer id, String groupName, Integer interestRate) {
		this.id = id;
		this.groupName = groupName;
		this.interestRate = interestRate;
	}
	
	public CustomerGroup() {}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getInterestRate(){
		return interestRate;
	}
	public void setInterestRate(Integer interestRate){
		this.interestRate = interestRate;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	

	
	
}
