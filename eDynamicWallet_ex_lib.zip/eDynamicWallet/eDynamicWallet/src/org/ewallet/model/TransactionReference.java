package org.ewallet.model;
import java.sql.Time;

public class TransactionReference {
	
	private Integer id;
	private Integer creditAccountId;
	private Integer DebitAccountId;
	private float amount;
	private String txnNote;
	private Time timestamp;
	
	
	/**
	 * @param id
	 * @param creditAccountId
	 * @param debitAccountId
	 * @param amount
	 * @param txnNote
	 * @param timestamp
	 */
	public TransactionReference(Integer id, Integer creditAccountId,
			Integer debitAccountId, float amount, String txnNote, Time timestamp) {
		this.id = id;
		this.creditAccountId = creditAccountId;
		DebitAccountId = debitAccountId;
		this.amount = amount;
		this.txnNote = txnNote;
		this.timestamp = timestamp;
	}
	
	public TransactionReference(){}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCreditAccountId() {
		return creditAccountId;
	}
	public void setCreditAccountId(Integer creditAccountId) {
		this.creditAccountId = creditAccountId;
	}
	public Integer getDebitAccountId() {
		return DebitAccountId;
	}
	public void setDebitAccountId(Integer debitAccountId) {
		DebitAccountId = debitAccountId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTxnNote() {
		return txnNote;
	}
	public void setTxnNote(String txnNote) {
		this.txnNote = txnNote;
	}
	public Time getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Time timestamp) {
		this.timestamp = timestamp;
	}
	
	

}
