package org.ewallet.model;

import java.util.Date;

public class Account {
	
	private Integer id;
	private Integer customerId;
	private float amount;
	private float interest;
	private float outstanding;
	private Date upate_on;
	
	/**
	 * @param id
	 * @param customerId
	 * @param amount
	 * @param interest
	 * @param outstanding
	 * @param upate_on
	 */
	public Account(Integer id, Integer customerId, float amount,
			float interest, float outstanding, Date upate_on) {
		
		this.id = id;
		this.customerId = customerId;
		this.amount = amount;
		this.interest = interest;
		this.outstanding = outstanding;
		this.upate_on = upate_on;
	}
	
	public Account(){}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getInterest() {
		return interest;
	}
	public void setInterest(float interest) {
		this.interest = interest;
	}
	public float getOutstanding() {
		return outstanding;
	}
	public void setOutstanding(float outstanding) {
		this.outstanding = outstanding;
	}
	public Date getUpate_on() {
		return upate_on;
	}
	public void setUpate_on(Date upate_on) {
		this.upate_on = upate_on;
	}
	
	
}
