/**
 * 
 */
/**
 * @author mohan
 *
 */
package org.ewallet.model;