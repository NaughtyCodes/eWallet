package org.ewallet.controller;

public class EcustomerRestController {

}
