package org.ewallet.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import org.ewallet.dao.CustomerGroupDAO;
import org.ewallet.dao.UserDAO;
import org.ewallet.model.Customer;
import org.ewallet.model.User;

@RestController
public class CustomerRestController {

	@Autowired
	private CustomerGroupDAO customerGroupDao;
	
	@Autowired
	private UserDAO userDao;

	@GetMapping("/")
	public String getStart() {
		return "welcome to ewallet";
	}
	
	@GetMapping("/CustomerGroups")
	public List getCustomerGroups() {
		return customerGroupDao.list();
	}
	
	@GetMapping("/users")
	public List getUserList() {
		return userDao.list();
	}
	
	@GetMapping("/users/{id}")
	public User getUser(@PathVariable int id) {
		System.out.println("inside of /user/{id}");
		return (User)userDao.get(id);
	}
	
	@PostMapping("/add/user")
	public void getUser(@RequestBody User user) {
		System.out.println("inside of /add/user");
		System.out.println(user.toString());
		userDao.saveOrUpdate(user);
	}
	
	@PostMapping("/upload") // //new annotation since 4.3
    public String singleFileUpload(@RequestParam("file") MultipartFile file) {
		
		 String UPLOADED_FOLDER = "D://";

        if (file.isEmpty()) {
        	return "{\"error\": file upload failed}";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);


        } catch (IOException e) {
            e.printStackTrace();
        }

        return "{\"info\": file upload success}";
    }

}