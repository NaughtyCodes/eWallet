package net.viralpatel.spring.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class HelloController {

	@RequestMapping("/hello")  
	 public ModelAndView sayHello() {  
	  String message = "This is comming from spring 4.0.6";  
	  return new ModelAndView("welcome", "message", message);  
	 }
	
	@RequestMapping("/test")
	public String getCustomers() {
		return "calling from rest ";
	}
}
